import RPi.GPIO as GPIO
import time

MotPin_1 = 11   # pin11
MotPin_2 = 12   # pin12
MotEn = 13  # pin13
YlwPin = 38 # pin15
RedPin = 40    # pin16

def setup():
    GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
    GPIO.setup(MotPin_1, GPIO.OUT)   # mode --- output
    GPIO.setup(MotPin_2, GPIO.OUT)
	
	
    GPIO.setup(MotEn, GPIO.OUT)
    GPIO.setup(YlwPin, GPIO.OUT)  # Yellow LED pin as output
    GPIO.setup(RedPin, GPIO.OUT)     # Red LED pin as output
    GPIO.output(MotEn, GPIO.LOW)  # motor stop

def loop():
    try:
        while True:
            print('Press Ctrl+C to end the program...')
            GPIO.output(MotEn, GPIO.HIGH)  # motor driver enable
			
            GPIO.output(MotPin_1, GPIO.HIGH)    # clockwise
            GPIO.output(MotPin_2, GPIO.LOW)
			
            GPIO.output(YlwPin, GPIO.HIGH) # Turn on yellow LED
            GPIO.output(RedPin, GPIO.LOW)     # Turn off red LED
            time.sleep(5)

            GPIO.output(MotEn, GPIO.LOW)   # motor stop
            GPIO.output(YlwPin, GPIO.LOW)  # Turn off yellow LED
            time.sleep(5)

            GPIO.output(MotEn, GPIO.HIGH)   # motor driver enable
            GPIO.output(MotPin_1, GPIO.LOW)      # anticlockwise
            GPIO.output(MotPin_2, GPIO.HIGH)
            GPIO.output(YlwPin, GPIO.LOW)   # Turn off yellow LED
            GPIO.output(RedPin, GPIO.HIGH)     # Turn on red LED
            time.sleep(5)

            GPIO.output(MotEn, GPIO.LOW)    # motor stop
            GPIO.output(RedPin, GPIO.LOW)      # Turn off red LED
            time.sleep(5)
    except KeyboardInterrupt:
        destroy()

def destroy():
    GPIO.output(MotEn, GPIO.LOW)  # motor stop
	
    GPIO.output(YlwPin, GPIO.LOW) # Turn off yellow LED
    GPIO.output(RedPin, GPIO.LOW)    # Turn off red LED
	
    GPIO.cleanup()  # Release resource

if __name__ == '__main__':
    setup()
    loop()